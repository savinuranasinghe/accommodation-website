<!-- footer section starts  -->

<footer class="footer">

   <section class="flex">

      <div class="box">
         <a href="tel:1112223333"><i class="fas fa-phone"></i><span>076 732 739</span></a>
         <a href="mailto:shaikhanas@gmail.com"><i class="fas fa-envelope"></i><span>375savinuranasinghe@gmail.com</span></a>
         <a href="#"><i class="fas fa-map-marker-alt"></i><span>85/5B Havelock road,Colombo 05.</span></a>
      </div>

      <div class="box">
      </div>

      <div class="box">
         <a href="#"><span>facebook</span><i class="fab fa-facebook-f"></i></a>
         <a href="#"><span>twitter</span><i class="fab fa-twitter"></i></a>
         <a href="#"><span>instagram</span><i class="fab fa-instagram"></i></a>

      </div>

   </section>

   <div class="credit">&copy; copyright @ <?= date('Y'); ?> by <span>Group T</span> | all rights reserved!</div>

</footer>

<!-- footer section ends -->